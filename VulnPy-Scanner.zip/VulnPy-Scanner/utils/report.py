import json
import os
from datetime import datetime

class Reporter:
    @staticmethod
    def generate_json(data, filename_prefix="vulnpy_report"):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{filename_prefix}_{timestamp}.json"
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            print(f"\n[+] Rapport généré avec succès : {os.path.abspath(filename)}")
        except Exception as e:
            print(f"\n[!] Erreur lors de la génération du rapport : {e}")
