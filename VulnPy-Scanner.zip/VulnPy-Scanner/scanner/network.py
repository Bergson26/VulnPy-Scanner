import nmap
import threading
from colorama import Fore, Style

class NetworkScanner:
    def __init__(self, target_range):
        self.target_range = target_range
        self.scanner = nmap.PortScanner()
        self.results = []
        self.lock = threading.Lock()

    def scan_host(self, host):
        print(f"{Fore.CYAN}[*] Scan de l'hôte : {host}{Style.RESET_ALL}")
        try:
            self.scanner.scan(host, arguments='-sV -T4 -F') 
            
            for proto in self.scanner[host].all_protocols():
                ports = self.scanner[host][proto].keys()
                for port in ports:
                    service = self.scanner[host][proto][port]
                    state = service['state']
                    
                    if state == 'open':
                        product = service.get('product', '')
                        version = service.get('version', '')
                        name = service.get('name', '')
                        
                        service_info = {
                            'host': host,
                            'port': port,
                            'protocol': proto,
                            'service': name,
                            'product': product,
                            'version': version
                        }
                        
                        with self.lock:
                            self.results.append(service_info)
                        
                        print(f"{Fore.GREEN}[+] Port {port} ouvert - Service: {name} {product} {version}{Style.RESET_ALL}")
                        
        except Exception as e:
            print(f"{Fore.RED}[!] Erreur lors du scan de {host}: {e}{Style.RESET_ALL}")

    def run_scan(self):
        print(f"{Fore.YELLOW}[*] Démarrage du scan sur {self.target_range}...{Style.RESET_ALL}")
        self.scanner.scan(hosts=self.target_range, arguments='-sn')
        active_hosts = self.scanner.all_hosts()
        
        threads = []
        for host in active_hosts:
            t = threading.Thread(target=self.scan_host, args=(host,))
            threads.append(t)
            t.start()
            
        for t in threads:
            t.join()
            
        return self.results
