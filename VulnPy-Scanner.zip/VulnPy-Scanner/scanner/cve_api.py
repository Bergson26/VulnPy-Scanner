import requests
import time
from colorama import Fore, Style

class CVEMapper:
    def __init__(self):
        self.base_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"

    def search_cve(self, product, version):
        if not product or not version:
            return []

        keyword = f"{product} {version}"
        print(f"{Fore.CYAN}[*] Recherche de CVE pour : {keyword}...{Style.RESET_ALL}")
        
        params = {
            'keywordSearch': keyword,
            'resultsPerPage': 5
        }
        
        try:
            response = requests.get(self.base_url, params=params)
            time.sleep(6) 
            
            if response.status_code == 200:
                data = response.json()
                vulnerabilities = data.get('vulnerabilities', [])
                
                cve_list = []
                for vuln in vulnerabilities:
                    cve = vuln.get('cve', {})
                    cve_id = cve.get('id')
                    
                    metrics = cve.get('metrics', {})
                    cvss = metrics.get('cvssMetricV31', [{}])[0].get('cvssData', {}).get('baseScore', 'N/A')
                    
                    if cve_id:
                        cve_list.append({'id': cve_id, 'cvss': cvss})
                        print(f"{Fore.RED}    -> Vulnérabilité trouvée : {cve_id} (Score CVSS: {cvss}){Style.RESET_ALL}")
                        
                return cve_list
            else:
                print(f"{Fore.YELLOW}[!] API NVD inaccessible (Code: {response.status_code}){Style.RESET_ALL}")
                return []
                
        except Exception as e:
            print(f"{Fore.RED}[!] Erreur lors de la requête API: {e}{Style.RESET_ALL}")
            return []
