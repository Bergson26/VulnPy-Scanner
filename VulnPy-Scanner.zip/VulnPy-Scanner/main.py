import argparse
import colorama
from colorama import Fore, Style
from scanner.network import NetworkScanner
from scanner.cve_api import CVEMapper
from utils.report import Reporter

def main():
    colorama.init()
    
    print(Fore.BLUE + r"""
     __     __    _       _____         ____                                 
     \ \   / /   | |     |  __ \       / __ \                                
      \ \_/ /   _| |_ __ | |__) |   _ | |  | | ___  ___ __ _ _ __  _ __ ___  
       \   / | | | | '_ \|  ___/ | | || |  | |/ __|/ __/ _` | '_ \| '_ ` _ \ 
        | || |_| | | | | | |   | |_| || |__| |\__ \ (_| (_| | | | | | | | | |
        |_| \__,_|_|_| |_|_|    \__, | \____/ |___/\___\__,_|_| |_|_| |_| |_|
                                 __/ |                                       
                                |___/                                        
    """ + Style.RESET_ALL)

    parser = argparse.ArgumentParser(description="VulnPy-Scanner : Outil de Reconnaissance & Mapping CVE")
    parser.add_argument("-t", "--target", help="Cible à scanner (ex: 192.168.1.1 ou 192.168.1.0/24)", required=True)
    parser.add_argument("-o", "--output", help="Format de sortie (json par défaut)", choices=['json'], default='json')
    
    args = parser.parse_args()
    
    scanner = NetworkScanner(args.target)
    scan_results = scanner.run_scan()
    
    if not scan_results:
        print(f"{Fore.YELLOW}[!] Aucun service identifié ou cible injoignable.{Style.RESET_ALL}")
        return

    mapper = CVEMapper()
    final_report = []
    
    print(f"\n{Fore.YELLOW}[*] Début de l'analyse CVE...{Style.RESET_ALL}")
    for service in scan_results:
        product = service['product']
        version = service['version']
        
        cve_data = []
        if product and version:
            cve_data = mapper.search_cve(product, version)
        
        service['vulnerabilities'] = cve_data
        final_report.append(service)

    Reporter.generate_json(final_report)

if __name__ == "__main__":
    main()
